

<?php $__env->startSection('title','Presensi Anggota'); ?>
<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-6">
			<div class="row">
				<div class="col-sm-12 col-md-6">
					<a href="<?php echo e(route('presensi.create')); ?>" class="btn btn-primary btn-block">Tambah Presensi</a>
				</div>
				<div class="col-sm-12 col-md-6">
					<a href="#"  data-toggle="modal" data-target="#export" class="btn btn-outline-success  btn-block">Export Presensi</a>
				</div>
			</div>
			<!-- Modal -->
			<form action="<?php echo e(route('presensi.export')); ?>" method="POST">
			<div class="modal fade" id="export" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
			  <div class="modal-dialog" role="document">
			    <div class="modal-content">
			      <div class="modal-header">
			        <h5 class="modal-title" id="exampleModalLabel">Export Presensi
			        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
			          <span aria-hidden="true">&times;</span>
			        </button>
			      </div>
			      <div class="modal-body">
			      	<?php echo csrf_field(); ?>
			        	<div class="row">
			        		<div class="col-md-6">
			        			<label>Tgl Awal</label>
			        			<input type="date" name="start" class="form-control">
			        		</div>
			        		<div class="col-md-6">
			        			<label>Tgl Akhir</label>
			        			<input type="date" name="end" class="form-control">
			        		</div>
			        	</div>
			       
			      </div>
			      <div class="modal-footer">
			       
			        <button type="submit" class="btn btn-primary">Expor Presensi</button>
			      </div>
			    </div>
			  </div>
			</div>
			 </form>
		</div>
		<div class="col-12">
			<hr>
			<div class="table-responsive">
				<table id="pengguna" class="table table-stripped table-bordered">
					<thead>
						<th>name</th>
						<th>no hp</th>
						<th>Tanggal</th>
						<th>Status Kehadiran</th>
						<th>aksi</th>
					</thead>
					<tbody>
						<?php $__currentLoopData = $presensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($dt->user->name); ?></td>
							<td><?php echo e($dt->user->no_hp); ?></td>
							<td><?php echo e($dt->tanggal); ?></td>
							<td>
								<?php if($dt->status_kehadiran == "H"): ?> 
								<span class="badge badge-success">Hadir</span>
								<?php elseif($dt->status_kehadiran == "I"): ?>
								<span class="badge badge-secondary">Izin</span>
								<?php elseif($dt->status_kehadiran == "A"): ?>
								<span class="badge badge-danger">Alpha</span>
								<?php elseif($dt->status_kehadiran == "S"): ?>
								<span class="badge badge-info">Sakit</span>
								<?php endif; ?>
							</td>
							<td>
								<a href="<?php echo e(route('presensi.edit',['id' => $dt->id])); ?>" class="btn btn-warning">Edit</a>
								<a onclick="return confirm('Apakah anda yakin ingin menghapus ini?');" href="<?php echo e(route('presensi.delete',['id' => $dt->id])); ?>" class="btn btn-danger">Hapus</a>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<script type="text/javascript">
$(document).ready( function () {
    $('#pengguna').DataTable();

} );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SISanggarTari\resources\views/admin/presensi/index.blade.php ENDPATH**/ ?>