
    <!-- Vendor css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/landing/vendors/@mdi/font/css/materialdesignicons.min.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-- Base css with customised bootstrap included -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/landing/css/miri-ui-kit-free.css')); ?>">

<?php /**PATH C:\xampp\htdocs\SISanggarTari\resources\views/layouts/partials/css.blade.php ENDPATH**/ ?>