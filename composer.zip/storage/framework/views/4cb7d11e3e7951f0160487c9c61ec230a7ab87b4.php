
<?php $__env->startSection('title','Tambahkan Presensi'); ?>
<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('presensi.save')); ?>" method="POST">
	<?php echo csrf_field(); ?>
	<div class="row">
		<div class="col-md-6 col-sm-12">
			<label>Pilih Anggota</label>
			<select name="user_id" id="user" class="form-control">
				<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($dt->id); ?>"><?php echo e($dt->name); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
		</div>
	</div>
	<div class="row">
		<div class="col-md-6 col-sm-12">
			<label>Status</label>
			<select name="status" class="form-control">
					<option value="H">Hadir</option>
					<option value="I">Izin</option>
					<option value="A">Alpha</option>
					<option value="S">Sakit</option>
			</select>
		</div>
	</div>
	<div class="row">
		<div class="col-md-6 col-sm-12">
			<label>Tanggal</label>
			<input type="date" max="<?php echo e(date('Y-m-d')); ?>" class="form-control" name="tanggal">
		</div>
	</div>
	<div class="row mt-3">
		<div class="col-md-6">
			<div class="row">
				<div class="col-sm-12 col-md-6">
					<button type="submit" class="btn btn-primary btn-block">Tambah Presensi</button>
				</div>
			</div>
		</div>
	</div>
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<script type="text/javascript">
	$(document).ready(function() {
    $('#user').select2();
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SISanggarTari\resources\views/admin/presensi/create.blade.php ENDPATH**/ ?>