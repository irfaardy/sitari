
<?php $__env->startSection('title','Ubah data Presensi'); ?>
<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('presensi.update')); ?>" method="POST">
	<?php echo csrf_field(); ?>
	<input type="hidden" name="id" value="<?php echo e($presensi->id); ?>">
	<div class="row">
		<div class="col-md-6 col-sm-12">
			<label>Nama Anggota</label><br>
			<?php echo e($presensi->user->name); ?>

		</div>
	</div>
	<div class="row">
		<div class="col-md-6 col-sm-12">
			<label>Status</label>
			<select name="status" class="form-control">
					<option value="H" <?php if($presensi->status_kehadiran == "H"): ?> selected <?php endif; ?>>Hadir</option>
					<option value="I" <?php if($presensi->status_kehadiran == "I"): ?> selected <?php endif; ?>>Izin</option>
					<option value="A" <?php if($presensi->status_kehadiran == "A"): ?> selected <?php endif; ?>>Alpha</option>
					<option value="S" <?php if($presensi->status_kehadiran == "S"): ?> selected <?php endif; ?>>Sakit</option>
			</select>
		</div>
	</div>
	<div class="row">
		<div class="col-md-6 col-sm-12">
			<label>Tanggal</label>
			<input required type="date" value="<?php echo e($presensi->tanggal); ?>" max="<?php echo e(date('Y-m-d')); ?>" class="form-control" name="tanggal">
		</div>
	</div>
	<div class="row mt-3">
		<div class="col-md-6">
			<div class="row">
				<div class="col-sm-12 col-md-6">
					<button type="submit" class="btn btn-primary btn-block">Update Presensi</button>
				</div>
			</div>
		</div>
	</div>
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<script type="text/javascript">
	$(document).ready(function() {
    $('#user').select2();
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SISanggarTari\resources\views/admin/presensi/edit.blade.php ENDPATH**/ ?>