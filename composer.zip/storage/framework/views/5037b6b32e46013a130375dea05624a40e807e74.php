

<?php $__env->startSection('title','Tagihan Sanggar Tari'); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-md-3 col-sm-12">
		<a href="<?php echo e(route('member.pembayaran.history')); ?>" class="btn-block btn btn-outline-primary">Riwayat Pembayaran</a>
	</div>
</div>
	<div class="row justify-content-center">
		<div class="col-md-6 col col-sm-12">
			<div class="card">
				<div class="card-body">
					<?php if($status != 1): ?>
					 
						<div align="center"><h5>Anda memiliki tagihan sanggar tari sebesar</h5><h4><b>Rp<?php echo e(number_format(($biaya->harga+$biaya->administrasi+(($biaya->harga+$biaya->administrasi)*($biaya->ppn/100))) * $presensi)); ?></b></h4></div>
						<b>Rincian tagihan:</b>
						<table class="table table-bordered table-striped">
							<?php if(!empty($invoice)): ?>
							<tr>
								<td>Invoice Code</td>
								<td align="right"><?php echo e($invoice); ?></td>
							</tr>
							<?php endif; ?>
							<tr>
								<td>Biaya Per-Sesi</td>
								<td align="right">Rp<?php echo e(number_format($biaya->harga)); ?></td>
							</tr>
							<tr>
								<td>Biaya Administrasi</td>
								<td align="right">Rp<?php echo e(number_format($biaya->administrasi)); ?></td>
							</tr>
							<?php if(!empty($biaya->ppn)): ?>
							<tr>
								<td>PPN (<?php echo e($biaya->ppn); ?>%)</td>
								<td align="right">Rp<?php echo e(number_format(($biaya->harga+$biaya->administrasi)*($biaya->ppn/100))); ?></td>
							</tr>
							<?php endif; ?>
							<tr>
								<td>Jumlah Absensi (Hadir)</td>
								<td align="right"><?php echo e($presensi); ?></td>
							</tr>
							<tr>
								<td>Total (<i>Biaya per-hari</i> × <i>Jumlah Absensi</i>)</td>
								<td align="right">Rp<?php echo e(number_format(($biaya->harga+$biaya->administrasi+(($biaya->harga+$biaya->administrasi)*($biaya->ppn/100))) * $presensi)); ?></td>
							</tr>
						
						</table>
						<?php else: ?>
						<div class="alert alert-success" align="center">
								<i class="fas fa-check mr-2 fa-3x"></i><br>Terimakasih<br>Tagihan bulan ini telah dibayarkan, anda dapat melihat pembayaran sebelumnya di "Riwayat Pembayaran"
							</div>
						<?php endif; ?>
						<hr>
						<?php if($cek_pembayaran == 0): ?>
						<?php if($presensi > 1): ?>
									<a href="<?php echo e(route('member.pembayaran.proses')); ?>" class="btn btn-primary btn-block">Bayar</a>
						<?php else: ?>
						<div class="alert alert-info" align="center">Tidak dapat melakukan pembayaran karena absensi anda masih kosong</div>
						<?php endif; ?>
						<?php else: ?>
							<?php if($status == 0): ?>
							<div class="alert alert-secondary" align="center">
								<i class="fas fa-clock mr-2"></i>Menunggu Verifikasi
							</div>
							<?php elseif($status == 2): ?>
							<div class="alert alert-danger" align="center">
								<i class="fas fa-times mr-2"></i>Ditolak
							</div>
								<?php if($presensi > 1): ?>
									<a href="<?php echo e(route('member.pembayaran.proses')); ?>" class="btn btn-primary btn-block">Bayar</a>
								<?php endif; ?>
							<?php endif; ?>
						<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SISanggarTari\resources\views/member/payment/index.blade.php ENDPATH**/ ?>