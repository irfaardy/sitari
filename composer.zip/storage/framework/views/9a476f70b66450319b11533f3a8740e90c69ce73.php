
<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('content'); ?>
	<h4>Pengumuman</h4>
	<div class="row">
		<div class="col-12">
			<hr>
			<div class="table-responsive">
				<table id="pengumuman" class="table table-stripped table-bordered">
					<thead>
						<th>Judul</th>
						<th>Deskripsi</th>
						<th>Tanggal</th>
						<th>aksi</th>
					</thead>
					<tbody>
						<?php $__currentLoopData = $pengumuman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($dt->title); ?></td>
							<td><?php echo e(strip_tags(Str::limit($dt->deskripsi,60))); ?></td>
							<td><?php echo e($dt->created_at); ?></td>
							<td>
								<a href="<?php echo e(route('pengumuman.detail',['id' => $dt->id])); ?>" class="btn btn-success">Selengkapnya</a>
							</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<script type="text/javascript">
$(document).ready( function () {
    $('#pengumuman').DataTable();

} );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SISanggarTari\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>