
<?php $__env->startSection('title','Tambahkan Pengguna'); ?>
<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('pengguna.update')); ?>" method="POST">
	<?php echo csrf_field(); ?>
	<input type="hidden" name="id" value="<?php echo e($user->id); ?>">
	<div class="row">
		<div class="col-md-6 col-sm-12">
			<label>Nama Lengkap</label>
			<input class="form-control" type="text" value="<?php echo e($user->name); ?>" name="name" required>
		</div>
		<div class="col-md-6 col-sm-12">
			<label>Email</label>
			<input class="form-control" type="email" value="<?php echo e($user->email); ?>" name="email" required>
		</div>
		<div class="col-md-6 col-sm-12">
			<label>Password</label>
			<input class="form-control" type="password" name="password" >
		</div>
		<div class="col-md-6 col-sm-12">
			<label>Konfirmasi Password</label>
			<input class="form-control" type="password" name="password_confirmation" >
		</div>
		<div class="col-md-6 col-sm-12">
			<label>No HP / WA</label>
			<input class="form-control" type="string" value="<?php echo e($user->no_hp); ?>" name="no_hp" required>
		</div>
		<div class="col-md-6 col-sm-12">
			<label>Role</label>
			<select name="role" class="form-control">
				<option value="member" <?php if($user->role == "member"): ?> selected="" <?php endif; ?>>member</option>
				<option value="admin" <?php if($user->role == "admin"): ?> selected="" <?php endif; ?>>admin</option>
			</select>
		</div>
		<div class="col-md-6 col-sm-12">
			<label>Tempat lahir</label>
			<input class="form-control" type="text" value="<?php echo e($user->tempat_lahir); ?>" name="tempat_lahir">
		</div>
		<div class="col-md-6 col-sm-12">
			<label>Tanggal lahir</label>
			<input class="form-control" type="date" value="<?php echo e($user->tanggal_lahir); ?>" name="tanggal_lahir">
		</div>
		<div class="col-md-12 col-sm-12">
			<label>Alamat</label>
			<textarea name="alamat_lengkap" class="form-control"><?php echo e($user->alamat_lengkap); ?></textarea>
			<hr>
		</div>
		<div class="col-md-6 col-sm-12">
			<label>Jenis Kelamin</label>
			<div class="mb-4">
	            <input  type="radio" value="L" id="jenis_kelamin_l" name="jenis_kelamin" <?php if($user->jenis_kelamin == "L"): ?> checked="" <?php endif; ?>>
	            <label class="form-check-label text-dark" for="jenis_kelamin_l">Laki-Laki</label>
	        </div> 
	        <div class="mb-4">
	            <input  type="radio" value="P" id="jenis_kelamin_p" name="jenis_kelamin" <?php if($user->jenis_kelamin == "P"): ?> checked="" <?php endif; ?>>
	            <label class="form-check-label text-dark" for="jenis_kelamin_p">Perempuan</label>
	        </div>
		</div>

		<div class="col-md-6 col-sm-12">
			<label>Status</label>
			<div class="mb-4">
	            <input  type="radio" <?php if($user->status == "1"): ?> checked="" <?php endif; ?> value="1" id="aktif" name="status" >
	            <label class="form-check-label text-dark" for="aktif">Aktif</label>
	        </div> 
	        <div class="mb-4">
	            <input <?php if($user->status == "2"): ?> checked="" <?php endif; ?>  type="radio" value="2" id="nonaktif" name="status" >
	            <label class="form-check-label text-dark" for="nonaktif">Non-Aktif</label>
	        </div>
		</div>

	</div>
	<div class="row">
		<div class="col-md-6">
			<div class="row">
				<div class="col-sm-12 col-md-6">
					<button type="submit" class="btn btn-primary btn-block">Update data Pengguna</button>
				</div>
			</div>
		</div>
	</div>
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SISanggarTari\resources\views/admin/pengguna/edit.blade.php ENDPATH**/ ?>