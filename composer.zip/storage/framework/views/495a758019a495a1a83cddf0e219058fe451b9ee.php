
<?php $__env->startSection('title','Ubah Biaya Sanggar'); ?>
<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('biaya.update')); ?>" method="POST">
	<?php echo csrf_field(); ?>
	<div class="row">
		<div class="col-md-6 col-sm-12">
			<label>Biaya</label>
			<input count id="biaya" class="form-control" type="number" value="<?php echo e($biaya->harga); ?>" min="0" name="harga" required>
		</div>
		<div class="col-md-6 col-sm-12">
			<label>Administrasi<small>*Opsional</small></label>
			<input count id="administrasi" class="form-control" type="number" value="<?php echo e($biaya->administrasi); ?>" min='0' name="administrasi">
		</div>
		<div class="col-md-3 col-sm-12">
			<label>PPN <small>*Opsional</small></label>
			<input count id="ppn" class="form-control" type="number" value="<?php echo e($biaya->ppn==null?0:$biaya->ppn); ?>" name="ppn">
		</div>
		

	</div>
	<div class="row mt-2">
		<div class="col-md-6">
			<div class="row">
				<div class="col-sm-12 col-md-6">
					<h5>Total Biaya</h5>
					Rp<span id="biaya-total"><?php echo e($biaya->harga+$biaya->administrasi+(($biaya->harga+$biaya->administrasi)*($biaya->ppn/100))); ?></span>
				</div>
			</div>
		</div>
	</div>

	<div class="row mt-2">
		<div class="col-md-6">
			<div class="row">
				<div class="col-sm-12 col-md-6">
					<button type="submit" class="btn btn-primary btn-block">Update Biaya</button>
				</div>
			</div>
		</div>
	</div>
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<script>
	$('[count]').keyup(function(e){
		var biaya = parseInt($('#biaya').val());
		var administrasi = parseInt($('#administrasi').val());
		var ppn = parseInt($('#ppn').val());
		var total = biaya+administrasi+((biaya+administrasi)*(ppn/100))
		$('#biaya-total').html(total.toLocaleString('en-US'))
	})
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SISanggarTari\resources\views/admin/biaya/edit.blade.php ENDPATH**/ ?>