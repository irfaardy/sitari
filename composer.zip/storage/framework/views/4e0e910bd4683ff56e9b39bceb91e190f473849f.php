
<?php $__env->startSection('title','Tambahkan Pengumuman'); ?>
<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('pengumuman.update')); ?>" method="POST">
	<?php echo csrf_field(); ?>
	<input type="hidden" name="id" value="<?php echo e($pengumuman->id); ?>">
	<div class="row">
		<div class="col-md-6 col-sm-12">
			<label>Judul</label>
			<input type="text" name="title" class="form-control" value="<?php echo e($pengumuman->title); ?>">
	</div>
	</div>
	<div class="row">
		<div class="col-md-12 col-sm-12">
			<label>Deskripsi Pengumuman</label>
			<textarea  name="deskripsi" class="form-control ck"><?php echo $pengumuman->deskripsi; ?></textarea>
		</div>
	</div>
	<div class="row mt-3">
		<div class="col-md-6">
			<div class="row">
				<div class="col-sm-12 col-md-6">
					<button type="submit" class="btn btn-primary btn-block">Simpan Pengumuman</button>
				</div>
			</div>
		</div>
	</div>
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<script src="https://cdn.ckeditor.com/4.19.1/standard/ckeditor.js"></script>
<script type="text/javascript">
	$(document).ready(function() {
     CKEDITOR.replace( 'deskripsi' );
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SISanggarTari\resources\views/admin/pengumuman/edit.blade.php ENDPATH**/ ?>