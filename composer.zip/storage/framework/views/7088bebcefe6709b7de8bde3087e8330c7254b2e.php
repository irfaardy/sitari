
<?php $__env->startSection('title',$pengumuman->title); ?>
<?php $__env->startSection('content'); ?>


	<div class="row">
		<div class="col-md-12 col-sm-12">
			
			<?php echo $pengumuman->deskripsi; ?>

		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SISanggarTari\resources\views/admin/pengumuman/detail.blade.php ENDPATH**/ ?>