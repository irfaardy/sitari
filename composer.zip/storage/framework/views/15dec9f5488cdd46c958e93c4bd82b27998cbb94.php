

<?php $__env->startSection('title','Riwayat Pembayaran'); ?>
<?php $__env->startSection('content'); ?>
	<div class="row">
		
		<div class="col-12">
			<hr>
			<div class="table-responsive">
				<table id="pembayaran" class="table table-stripped table-bordered">
					<thead>
						<th>No Invoice</th>
						<th>Biaya</th>
						<th>Administrasi</th>
						<th>PPN</th>
						<th>Absensi</th>
						<th>Total</th>
						<th>Status</th>
						<th>Waktu Pembayaran</th>
					</thead>
					<tbody>
						<?php $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($dt->invoice_code); ?></td>
							<td><?php echo e($dt->harga); ?></td>
							<td><?php echo e($dt->biaya_administrasi); ?></td>
							<td><?php echo e(empty($dt->ppn)?"-":$dt->ppn); ?></td>
							<td><?php echo e($dt->jumlah_presensi); ?></td>
							<td><?php echo e($dt->total_harga); ?></td>
							<td>
								<?php if($dt->status_pembayaran == 0): ?>
									<span class="badge badge-secondary">Menunggu Verifikasi</span>
								<?php elseif($dt->status_pembayaran == 1): ?>
									<span class="badge badge-success">Lunas</span>
								<?php elseif($dt->status_pembayaran == 2): ?>
									<span class="badge badge-success">Ditolak</span>
								<?php endif; ?>
							</td>
							<td><?php echo e($dt->dibayarkan_pada); ?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<script type="text/javascript">
$(document).ready( function () {
    $('#pembayaran').DataTable();

} );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SISanggarTari\resources\views/member/payment/riwayat_pembayaran.blade.php ENDPATH**/ ?>