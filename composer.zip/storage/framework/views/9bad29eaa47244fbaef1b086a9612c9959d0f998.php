



<?php $__env->startSection('title','Lakukan Absen Hari ini'); ?>

<?php $__env->startSection('content'); ?>


	<div class="row justify-content-center">

		<div class="col-md-6 col col-sm-12">

			<div class="card">

				<div class="card-body" align="center">
					<h4><b>Nama:</b><br><?php echo e(auth()->user()->name); ?></h4>
					<h4><b>Tanggal:</b><br><?php echo e(date("d/m/Y")); ?></h4>
						<hr>
					<?php if(!empty($presensi)): ?>
					<div class="alert alert-info">Anda sudah melakukan absen hari ini pada jam <?php echo e(date("H:i",strtotime($presensi->created_at))); ?></div>
					<?php else: ?>

					<form action="<?php echo e(route('presensi.action')); ?>" method="post">
						<?php echo csrf_field(); ?>
						<button class="btn btn-success btn-block">Klik disini untuk absensi</button>
					</form>
					<?php endif; ?>
				</div>

			</div>

		</div>

	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SISanggarTari\resources\views/member/absen.blade.php ENDPATH**/ ?>