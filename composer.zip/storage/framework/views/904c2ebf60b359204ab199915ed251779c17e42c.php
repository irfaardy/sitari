<?php if(Session::has('message_success')): ?>
<script type="text/javascript">
      $(function() {
        const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 3000
    });
     Toast.fire({
            icon: 'success',
            title: " <?php echo e(Session::get('message_success')); ?>"
          })
    });
    </script>
<?php endif; ?>
<?php if(Session::has('message_fail')): ?>
<script type="text/javascript">
      $(function() {
        const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 3000
    });
     Toast.fire({
            icon: 'error',
            title: " <?php echo e(Session::get('message_fail')); ?>"
          })
    });
    </script>
<?php endif; ?>
<?php if(Session::has('message_warning')): ?>
<script type="text/javascript">
      $(function() {
        const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 3000
    });
     Toast.fire({
            icon: 'warning',
            title: " <?php echo e(Session::get('message_warning')); ?>"
          })
    });
    </script>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\SISanggarTari\resources\views/layouts/partials/alert.blade.php ENDPATH**/ ?>