<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="shortcut icon" href="assets/images/favicon.ico" type="image/x-icon">
    <title>Sanggar Tari Ayunindya's</title>

    <?php echo $__env->make('layouts/partials/css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body class="login-page">
    <header class="miri-ui-kit-header header-no-bg-img header-navbar-only"><?php echo $__env->make('layouts/partials/nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </header>
    <?php echo $__env->yieldContent('content'); ?>
   
   <?php echo $__env->make('layouts/partials/js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\SISanggarTari\resources\views/layouts/master_login.blade.php ENDPATH**/ ?>