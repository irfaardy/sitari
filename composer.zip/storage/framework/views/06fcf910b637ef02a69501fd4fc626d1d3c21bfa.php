<table border="1px">
	<tr>
		<td style="border: 1px #000 solid;" colspan="9" align="center">Laporan Transaksi <?php echo e($range); ?> (Status: <?php echo e($status); ?>)</td>
	</tr>
	<tr>
		<td ><b>Invoice</b></td>
		<td ><b>Nama</b></td>
		<td ><b>No Hp</b></td>
		<td ><b>Jumlah Absensi</b></td>
		<td ><b>Biaya Admin</b></td>
		<td ><b>Biaya Sanggar</b></td>
		<td ><b>PPN</b></td>
		<td ><b>Total</b></td>
		<td ><b>Waktu Pembayaran</b></td>
	</tr>
	<?php $i=1; 
		$biaya_adm =0;
		$harga =0;
		$ppn =0;
		$total_harga =0;
		 ?>`
	<?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php 
		$biaya_adm += $t->biaya_administrasi;
		$harga += $t->harga;
		$ppn += $t->ppn;
		$total_harga += $t->total_harga;
	?>
	<tr>
		<td><?php echo e($t->invoice_code); ?></td>
		<td><?php echo e($t->user->name); ?></td>
		<td><?php echo e($t->user->no_hp); ?></td>
		<td><?php echo e($t->jumlah_presensi); ?></td>
		<td><?php echo e($t->biaya_administrasi); ?></td>
		<td><?php echo e($t->harga); ?></td>
		<td><?php echo e(empty($t->ppn)?"-":$t->ppn); ?></td>
		<td><?php echo e($t->total_harga); ?></td>
		<td><?php echo e($t->dibayarkan_pada); ?></td>
	</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td colspan="4" align="center"><b>Total</b></td>
		<td><b><?php echo e($biaya_adm); ?></b></td>
		<td><b><?php echo e($harga); ?></b></td>
		<td><b><?php echo e($ppn); ?></b></td>
		<td><b><?php echo e($total_harga); ?></b></td>
	</tr>
</table><?php /**PATH C:\xampp\htdocs\SISanggarTari\resources\views/exports/transaksi.blade.php ENDPATH**/ ?>